import { CVNavigation } from "@/components/cv-navigation"
import { CVHeader } from "@/components/cv-header"
import { CVProfile } from "@/components/cv-profile"
import { CVExperience } from "@/components/cv-experience"
import { CVEducation } from "@/components/cv-education"
import { CVSkills } from "@/components/cv-skills"
import { CVReferences } from "@/components/cv-references"

export default function HomePage() {
  return (
    <div className="flex flex-col md:flex-row bg-background min-h-screen">
      <CVNavigation />

      <main className="flex-1 p-6 md:p-12 overflow-y-auto">
        <div className="max-w-4xl mx-auto space-y-16">
          <CVHeader />
          <CVProfile />
          <CVExperience />
          <CVEducation />
          <CVSkills />
          <CVReferences />
        </div>
      </main>
    </div>
  )
}
