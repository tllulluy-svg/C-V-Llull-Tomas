"use server"

import { generateText } from "ai"

const CV_CONTENT = `
Tomás Llull - Administrativo Contable

PERFIL PROFESIONAL:
Estudiante avanzado de Contador Público con experiencia práctica en roles contables. 
Responsable y detallista en la gestión de información financiera. Experto en Excel para 
análisis de datos y optimización de procesos.

EXPERIENCIA LABORAL:

1. Administrativo Contable - La Fonte D´Oro (Julio 2024 - Actualidad)
   Logro destacado: Optimicé el proceso de conciliación de extractos bancarios mediante 
   una solución en Excel y herramientas de IA, eliminando la carga manual de datos y 
   reduciendo significativamente el error humano.
   
   Responsabilidades:
   - Gestión integral de conciliaciones bancarias y de tarjetas de crédito
   - Análisis y conciliación de cuentas corrientes y facturación a franquicias
   - Registración y control de gastos e impuestos
   - Elaboración de informes de estados de resultados
   - Conciliación de plataformas de pago (Pedidos Ya, Mercado Pago)
   - Gestión multicempresa

2. Asistente Contable - De las Pampas Resort (Marzo 2023 - Julio 2024)
   - Conciliaciones bancarias, de tarjetas y de caja
   - Manejo de cuentas corrientes de clientes y proveedores
   - Gestión de pagos a proveedores
   - Supervisión de libros IVA Compra y Venta
   - Cálculo y liquidación de comisiones

3. Administrativo - Soluciones Turísticas EVT (Enero 2022 - Marzo 2023)
   Logro destacado: Diseñé e implementé un sistema de seguimiento de cuentas corrientes 
   de proveedores en Excel y Google Sheets, centralizando información y formalizando 
   el proceso de pagos.
   
   - Gestión de cuentas bancarias
   - Administración de cadena de pagos
   - Registración de facturación

EDUCACIÓN:
- Contador Público (En Proceso) - Universidad Nacional de Mar del Plata (2023 - actualidad)
- Bachiller en Economía y Administración - Instituto Peralta Ramos (2012 - 2018)

COMPETENCIAS:
- Software: Excel - Nivel Especialista, Google Workspace
- Sistemas de Gestión: ERP Holistor (Nivel Avanzado)
- Idiomas: Inglés (Nivel B1)

CONTACTO:
Email: t.llullarg@gmail.com
Teléfono: +54 223 606-7630
`

export async function generateCoverLetter(jobDescription: string): Promise<string> {
  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      system: `Actúa como un redactor de RR.HH. profesional. Tu tarea es generar una carta de presentación (máximo 3 párrafos, en español, formal y concisa) para el CV proporcionado, adaptándola a la Descripción del Puesto. La carta debe destacar los logros clave del CV que son relevantes para el puesto. No incluyas direcciones ni saludos formales (ej: "Estimado/a"). Empieza directamente con el cuerpo de la carta.`,
      prompt: `Este es el CV:
---
${CV_CONTENT}
---

Y esta es la Descripción del Puesto: "${jobDescription}"

Genera la carta de presentación profesional, comenzando directamente con el primer párrafo.`,
    })

    return text
  } catch (error) {
    console.error("Error generating cover letter:", error)
    throw new Error("Failed to generate cover letter")
  }
}
