export function CVSkills() {
  const skills = [
    {
      title: "Software",
      description: "Paquete Office (Excel - Nivel Especialista), Google Workspace (Sheets, Docs).",
    },
    {
      title: "Sistemas de Gestión",
      description: "ERP Holistor (Nivel Avanzado).",
    },
    {
      title: "Idiomas",
      description: "Inglés (Nivel B1 - Competencia en lectura / Nivel 6 completado en ICA).",
    },
  ]

  return (
    <section id="competencias">
      <h2 className="text-3xl md:text-4xl font-extrabold text-primary border-b-4 border-primary pb-3 mb-8">
        Competencias Técnicas y Lingüísticas
      </h2>
      <p className="text-lg md:text-xl text-muted-foreground mb-8">Las herramientas y habilidades que domino.</p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {skills.map((skill, index) => (
          <div key={index} className="bg-card p-6 rounded-xl shadow-lg border border-border">
            <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-2">{skill.title}</h3>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
              {skill.description.includes("Excel") ? (
                <>
                  Paquete Office (<strong className="text-primary">Excel - Nivel Especialista</strong>), Google
                  Workspace (Sheets, Docs).
                </>
              ) : (
                skill.description
              )}
            </p>
          </div>
        ))}
      </div>
    </section>
  )
}
