import { ExperienceCard } from "./experience-card"

export function CVExperience() {
  const experiences = [
    {
      title: "Administrativo Contable",
      company: "La Fonte D´Oro",
      period: "Julio 2024 - Actualidad",
      highlight: {
        title: "Logro Destacado (Optimización):",
        description:
          "Optimicé el proceso de conciliación de extractos bancarios mediante una solución desarrollada en Excel y herramientas de IA. Esta automatización eliminó la carga manual de datos, reduciendo significativamente el error humano y agilizando la entrega de informes.",
      },
      responsibilities: [
        "Gestión integral de conciliaciones bancarias y de tarjetas de crédito.",
        "Análisis y conciliación de cuentas corrientes y facturación a franquicias.",
        "Registración y control de gastos e impuestos.",
        "Elaboración de informes de estados de resultados.",
        "Conciliación de plataformas de pago (Pedidos Ya, Mercado Pago) y control de precios.",
        "Gestión multicempresa (La Fonte d'Oro, Desarrollo Gastronómico Guapas, Operadora Riva y Gran Hotel Panamericano).",
      ],
    },
    {
      title: "Asistente Contable",
      company: "De las Pampas Resort",
      period: "Marzo 2023 - Julio 2024",
      responsibilities: [
        "Ejecución de conciliaciones bancarias, de tarjetas y de caja.",
        "Manejo y conciliación de cuentas corrientes de clientes y proveedores.",
        "Gestión y procesamiento de pagos a proveedores.",
        "Registración, control y comparación de datos contables.",
        "Supervisión de libros IVA Compra y Venta.",
        "Cálculo y liquidación de comisiones.",
        "Conciliación entre sistema de gestión y reservas hoteleras.",
      ],
    },
    {
      title: "Administrativo",
      company: "Soluciones Turísticas EVT",
      period: "Enero 2022 - Marzo 2023",
      highlight: {
        title: "Logro Destacado (Implementación):",
        description:
          "Diseñé e implementé un sistema de seguimiento de cuentas corrientes de proveedores en Excel y Google Sheets. Esta iniciativa centralizó la información dispersa y formalizó el proceso de pagos, reemplazando un sistema informal de pagos en efectivo.",
      },
      responsibilities: [
        "Gestión de las cuentas bancarias de la compañía.",
        "Administración de la cadena de pagos (proveedores, impuestos, servicios, nómina).",
        "Registración de facturación y seguimiento de cuentas corrientes.",
        "Gestión y control de novedades de personal y arqueos de caja a sucursales.",
      ],
    },
  ]

  return (
    <section id="experiencia">
      <h2 className="text-3xl md:text-4xl font-extrabold text-primary border-b-4 border-primary pb-3 mb-8">
        Experiencia Laboral
      </h2>
      <p className="text-lg md:text-xl text-muted-foreground mb-8">
        Un resumen de mis roles, responsabilidades y logros clave en mis puestos anteriores.
      </p>
      <div className="space-y-12">
        {experiences.map((exp, index) => (
          <ExperienceCard key={index} {...exp} />
        ))}
      </div>
    </section>
  )
}
