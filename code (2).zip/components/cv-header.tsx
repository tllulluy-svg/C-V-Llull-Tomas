import Image from "next/image"

export function CVHeader() {
  return (
    <header className="flex flex-col md:flex-row items-center justify-between border-b pb-8 border-border">
      <div className="text-center md:text-left">
        <h1 className="text-5xl md:text-6xl font-extrabold text-foreground leading-tight text-balance">Tomás Llull</h1>
        <h2 className="text-3xl md:text-4xl font-bold text-primary mt-2">Administrativo Contable</h2>
        <div className="mt-6 text-lg md:text-xl text-muted-foreground space-y-2">
          <p>
            <strong className="text-foreground">Email:</strong> t.llullarg@gmail.com
          </p>
          <p>
            <strong className="text-foreground">Teléfono:</strong> +54 223 606-7630
          </p>
        </div>
      </div>
      <div className="mt-8 md:mt-0 flex-shrink-0">
        <div className="w-40 h-40 md:w-48 md:h-48 rounded-full overflow-hidden shadow-2xl border-4 border-white relative bg-primary/10">
          <Image
            src="/profile-photo.png"
            alt="Foto de perfil de Tomás Llull"
            width={192}
            height={192}
            className="object-cover w-full h-full"
            priority
          />
        </div>
      </div>
    </header>
  )
}
