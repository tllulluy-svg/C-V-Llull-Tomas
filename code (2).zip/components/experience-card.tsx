interface ExperienceCardProps {
  title: string
  company: string
  period: string
  highlight?: {
    title: string
    description: string
  }
  responsibilities: string[]
}

export function ExperienceCard({ title, company, period, highlight, responsibilities }: ExperienceCardProps) {
  return (
    <div className="bg-card p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-border">
      <h3 className="text-2xl md:text-3xl font-bold text-foreground">{title}</h3>
      <p className="text-lg md:text-xl font-semibold text-primary mt-1">{company}</p>
      <p className="text-lg md:text-xl font-bold text-muted-foreground italic mt-1">{period}</p>

      {highlight && (
        <div className="bg-primary/5 border-l-4 border-primary p-4 rounded-lg mt-4 shadow-sm">
          <p className="font-bold text-primary text-base md:text-lg">{highlight.title}</p>
          <p className="text-base md:text-lg text-foreground mt-1">{highlight.description}</p>
        </div>
      )}

      <ul className="list-disc list-inside text-base md:text-lg text-muted-foreground mt-4 space-y-2">
        {responsibilities.map((resp, index) => (
          <li key={index}>{resp}</li>
        ))}
      </ul>
    </div>
  )
}
