export function CVReferences() {
  return (
    <section id="referencias">
      <h2 className="text-3xl md:text-4xl font-extrabold text-primary border-b-4 border-primary pb-3 mb-8">
        Referencias
      </h2>
      <div className="bg-card p-6 rounded-xl shadow-lg border border-border">
        <div className="text-lg md:text-xl text-foreground space-y-3">
          <p>
            <strong>C.P. Vanesa Imbelloni</strong>, De las Pampas Resort SA, +54 223 5860392.
          </p>
          <p className="italic text-muted-foreground">Referencias adicionales disponibles a solicitud.</p>
        </div>
      </div>
    </section>
  )
}
