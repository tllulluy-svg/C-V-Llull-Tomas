"use client"

import { useState } from "react"
import { Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { generateCoverLetter } from "@/app/actions"

export function AIAssistant() {
  const [jobDescription, setJobDescription] = useState("")
  const [coverLetter, setCoverLetter] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleGenerate = async () => {
    if (!jobDescription.trim()) {
      setCoverLetter("Por favor, pega la descripción del puesto de trabajo antes de continuar.")
      return
    }

    setIsLoading(true)
    setCoverLetter("")

    try {
      const result = await generateCoverLetter(jobDescription)
      setCoverLetter(result)
    } catch (error) {
      setCoverLetter("Hubo un error al generar la carta. Por favor, intenta de nuevo.")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <section id="asistente-ia" className="border-t pt-8 border-border">
      <h2 className="text-3xl md:text-4xl font-extrabold text-primary border-b-4 border-primary pb-3 mb-8 flex items-center gap-2">
        Asistente IA para Aplicaciones <Sparkles className="h-8 w-8" />
      </h2>
      <p className="text-lg md:text-xl text-muted-foreground mb-6">
        Genera una carta de presentación profesional y adaptada a cualquier oferta de trabajo. La IA utilizará tus
        logros y experiencia en el CV para hacerla relevante.
      </p>

      <div className="space-y-4">
        <Textarea
          value={jobDescription}
          onChange={(e) => setJobDescription(e.target.value)}
          rows={6}
          className="text-base md:text-lg"
          placeholder="Pega aquí la descripción completa del puesto de trabajo o un título de la oferta para la que aplicas..."
        />

        <Button onClick={handleGenerate} disabled={isLoading} className="w-full text-base md:text-lg py-6">
          {isLoading ? (
            <>Generando carta, espera un momento...</>
          ) : (
            <>
              Generar Carta de Presentación <Sparkles className="ml-2 h-5 w-5" />
            </>
          )}
        </Button>

        <div className="bg-card p-6 border border-border rounded-xl shadow-xl min-h-[150px]">
          {coverLetter ? (
            <div className="text-base md:text-lg text-foreground whitespace-pre-wrap leading-relaxed">
              {coverLetter}
            </div>
          ) : (
            <p className="italic text-muted-foreground text-center">La carta generada por IA aparecerá aquí.</p>
          )}
        </div>
      </div>
    </section>
  )
}
