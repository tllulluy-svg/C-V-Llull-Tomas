export function CVEducation() {
  return (
    <section id="educacion">
      <h2 className="text-3xl md:text-4xl font-extrabold text-primary border-b-4 border-primary pb-3 mb-8">
        Educación
      </h2>
      <p className="text-lg md:text-xl text-muted-foreground mb-8">Mi formación académica y profesional.</p>
      <div className="space-y-6 bg-card p-6 rounded-xl shadow-lg border border-border">
        <div>
          <h3 className="text-2xl md:text-3xl font-bold text-foreground">Contador Público (En Proceso)</h3>
          <p className="text-lg md:text-xl text-muted-foreground mt-1">Universidad Nacional de Mar del Plata</p>
          <p className="text-lg md:text-xl font-bold text-muted-foreground italic mt-1">2023 - actualidad</p>
        </div>
        <div className="pt-4 border-t border-border">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground">Ingeniería (Incompleto)</h3>
          <p className="text-lg md:text-xl text-muted-foreground mt-1">Universidad Nacional de Mar del Plata</p>
          <p className="text-lg md:text-xl font-bold text-muted-foreground italic mt-1">2019 - 2022</p>
        </div>
        <div className="pt-4 border-t border-border">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground">Bachiller en Economía y Administración</h3>
          <p className="text-lg md:text-xl text-muted-foreground mt-1">Instituto Peralta Ramos</p>
          <p className="text-lg md:text-xl font-bold text-muted-foreground italic mt-1">2012 - 2018</p>
        </div>
      </div>
    </section>
  )
}
