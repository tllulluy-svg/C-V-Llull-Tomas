"use client"

import { User, Briefcase, BookOpen, Award, Download } from "lucide-react"

export function CVNavigation() {
  const handleDownloadPDF = () => {
    if (typeof window !== "undefined") {
      window.print()
    }
  }

  return (
    <nav className="w-full md:w-20 bg-primary text-primary-foreground flex md:flex-col justify-around items-center p-4 md:py-8 shadow-lg md:h-screen md:sticky md:top-0 z-10">
      <a
        href="#perfil"
        title="Perfil Profesional"
        className="p-2 rounded-full hover:bg-primary/80 transition-colors duration-200"
      >
        <User className="h-8 w-8" />
      </a>

      <a
        href="#experiencia"
        title="Experiencia Laboral"
        className="p-2 rounded-full hover:bg-primary/80 transition-colors duration-200"
      >
        <Briefcase className="h-8 w-8" />
      </a>

      <a
        href="#educacion"
        title="Educación"
        className="p-2 rounded-full hover:bg-primary/80 transition-colors duration-200"
      >
        <BookOpen className="h-8 w-8" />
      </a>

      <a
        href="#competencias"
        title="Competencias"
        className="p-2 rounded-full hover:bg-primary/80 transition-colors duration-200"
      >
        <Award className="h-8 w-8" />
      </a>

      <button
        onClick={handleDownloadPDF}
        title="Descargar PDF"
        className="p-2 rounded-full hover:bg-primary/80 transition-colors duration-200"
      >
        <Download className="h-8 w-8" />
      </button>
    </nav>
  )
}
