export function CVProfile() {
  return (
    <section id="perfil">
      <h2 className="text-3xl md:text-4xl font-extrabold text-primary border-b-4 border-primary pb-3 mb-8">
        Perfil Profesional
      </h2>
      <div className="bg-card p-6 rounded-xl shadow-lg border-l-4 border-primary">
        <p className="text-lg md:text-xl font-medium text-card-foreground leading-relaxed">
          Estudiante avanzado de Contador Público con experiencia práctica en roles contables. Me caracterizo por mi
          enfoque <strong>responsable y detallista</strong> en la gestión de la información financiera. Cuento con
          manejo experto de <strong>Excel para el análisis de datos</strong> y la optimización de procesos. Busco
          aplicar mis conocimientos y contribuir a un equipo de trabajo dinámico.
        </p>
      </div>
    </section>
  )
}
